⚪ Adaptive Theme 2 (According to the currently open web page)
Download "Adaptive Tab Bar Color" and "Darkreader" addon.
Set "automation" to "use system color scheme" or "active hours" in the dark reader settings.

/////////////////////////////////

⚪ Fixed dark/light Theme:

Install these color themes to get the correct colors:

https://addons.mozilla.org/en-US/firefox/addon/safari-ventura-dark/
https://addons.mozilla.org/en-US/firefox/addon/safari-ventura-light/

Then, install "automaticDark" addon to automatically switch between dark/light mode:

https://addons.mozilla.org/tr/firefox/addon/automatic-dark/?utm_source=addons.mozilla.org&utm_medium=referral&utm_content=search

(Select Safari Ventura Light as "Daytime theme" and Safari Ventura Dark as "Nighttime theme" in addons setting.)



********************************
For more information: 
https://github.com/denizjcan/Firefox-Safari-15-Theme