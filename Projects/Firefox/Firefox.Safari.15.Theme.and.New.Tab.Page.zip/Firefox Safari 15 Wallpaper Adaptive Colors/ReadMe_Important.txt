⚪ Make the system colors (accent colors) "automatic" in the Windows Settings.
Windows settings > Personalisation > Theme color > select "Automatic"

⚪ Select "System theme - automatic" from Firefox native themes.
Firefox settings > Add-ons and Themes > Themes > select "System theme-automatic"

---
(If you want a certain color, you can choose the color you want under Theme Color instead of automatic.)







********************************
For more information: 
https://github.com/denizjcan/Firefox-Safari-15-Theme