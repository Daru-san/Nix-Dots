⚪ Safari Theme Tutorial:

‣ https://github.com/denizjcan/Firefox-Safari-15-Theme



⚪ Safari New Tab/Start Page Tutorial:

‣ https://drive.google.com/file/d/1BcFr5fgouuSwQ-e7icRSdUYI-DvcGiG_/view?usp=share_link


⁃ Required Websites for New Tab/Start Page page:

‣ https://www.own-free-website.com/
‣ https://htmlg.com/html-editor/ (Editor)



___________
@denizjcan
