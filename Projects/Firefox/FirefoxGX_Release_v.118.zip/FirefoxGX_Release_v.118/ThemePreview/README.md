# Main User Interface

### New Tab Page

![light-dark](https://user-images.githubusercontent.com/22057609/211889538-4cd75d99-8ffc-4516-8286-b3cc766ae8d2.png)

### Tab-Shapes

![GX-Tab_shapes](https://user-images.githubusercontent.com/22057609/211902860-d9b885f2-9a62-4eae-8adc-fa27ee92f24f.png)

### Preferences Page

![imagen](https://user-images.githubusercontent.com/22057609/186515863-c6ded24a-4621-4efd-99ea-191ff235f906.png)

### Add-ons Page

![imagen](https://user-images.githubusercontent.com/22057609/186515986-32e39e37-6c83-4927-87a5-0d9a755f4c5a.png)

### Library

![imagen](https://user-images.githubusercontent.com/22057609/186516532-74953222-4c35-4f16-a4cc-0e1a07d02681.png)

### Hamburguer Menu - Contextual Menus

![imagen](https://user-images.githubusercontent.com/22057609/186518856-2a474e30-40fa-4af0-a8df-02d27d00403b.png)

### Oneline Config

![imagen](https://user-images.githubusercontent.com/22057609/196294613-0d40bef9-e1e2-4ec3-a44e-b6ff3cce5433.png)

### Main-image Config

![imagen](https://user-images.githubusercontent.com/22057609/196325185-8762466b-97c9-4eeb-9e0b-42a2f475046c.png)

### Left Side-Bar Config

![imagen](https://user-images.githubusercontent.com/22057609/196332981-707d0b09-4e69-418d-a521-024c57f14745.png)

### Tree style tabs Config

![imagen](https://user-images.githubusercontent.com/22057609/194778844-2e13dd30-edd3-4be4-9ad4-6f365c027653.png)
