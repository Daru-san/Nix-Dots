## Display  a sidebar with whatsapp web.

## How to apply?
<ol><li>Drop the <code>SidebarWhatsapp@Godie.xpi</code> file into firefox browser.</li>
 <li>Acept to install the extension.</li></ol>

## Preview

![ChatWappPrev](https://github.com/Godiesc/firefox-gx/assets/22057609/6ac769a9-b1ec-4d2a-af58-a6d5d6457dcf)
