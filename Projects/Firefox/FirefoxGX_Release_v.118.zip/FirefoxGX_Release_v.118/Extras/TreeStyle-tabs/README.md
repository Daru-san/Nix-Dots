## Tree style tabs Extension. [[Link to Extension]](https://addons.mozilla.org/es/firefox/addon/tree-style-tab/)

### Preview

![imagen](https://user-images.githubusercontent.com/22057609/209135663-428875eb-e0ab-40fc-8c4d-cbdd5fc567d7.png)


## Tab Center Reborn Extension. [[Link to Extension]](https://addons.mozilla.org/es/firefox/addon/tabcenter-reborn/)

### Preview - Config 1

![imagen](https://user-images.githubusercontent.com/22057609/209564040-67e8cf47-e839-4c02-9310-6304ccfcd853.png)

### Preview - Config 2
![imagen](https://user-images.githubusercontent.com/22057609/209563130-1b901142-18bc-4fe2-a5d2-651c2165fb87.png)
