# How to apply. 
<ol>
  <li>Add the file <code>ogx_oneline.css</code> into the <code>chrome/components</code> folder.</li>
  <li>Delete "Flexible Space" and put the icons just like the image below. </li>
</ol>

## Position of buttons before apply the One-line config

![OnelineSplashParaPosiciónBotones](https://user-images.githubusercontent.com/22057609/213766636-6cc2cbe4-4c1d-4b6a-92d1-323857a420f0.png)

## Preview
![imagen](https://user-images.githubusercontent.com/22057609/196294613-0d40bef9-e1e2-4ec3-a44e-b6ff3cce5433.png)

![imagen](https://user-images.githubusercontent.com/22057609/206764591-03a8766e-6f83-4343-a5a6-aa2db6e1addf.png)
