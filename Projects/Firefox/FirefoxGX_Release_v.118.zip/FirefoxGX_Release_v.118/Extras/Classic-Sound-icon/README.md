## How to apply

Makes the tabs to display an animated image when playing sound. This config works togetter with the context line of containers, 
so to apply the config just copy and paste the two files into <code>chrome</code> >> <code>components</code> folder.

![SoundConfig](https://user-images.githubusercontent.com/22057609/204435351-7be346ad-96fa-4893-8f9c-57433c30c861.gif)
